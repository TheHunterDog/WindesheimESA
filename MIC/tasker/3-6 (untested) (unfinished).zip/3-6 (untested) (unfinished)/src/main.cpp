#include <avr/interrupt.h>
#include <twi.h>
#include <util/delay.h>
#define SUBMAIN 0x38

int main(int argc, char const *argv[])
{
  twi_init(); 
  sei();
  while (1)
  {
    // Wire.beginTransmission(SUBMAIN);
    // Wire.write(0xAA);
    // Wire.endTransmission();
    // _delay_ms(200);
    // Wire.beginTransmission(SUBMAIN);
    // Wire.write(0x55);
    // Wire.endTransmission();
    _delay_ms(200);
  }
  return 0;
}
