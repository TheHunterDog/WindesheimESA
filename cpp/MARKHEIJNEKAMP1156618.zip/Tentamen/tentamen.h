#ifndef TENTAMEN___H
#define TENTAMEN___H

void opdracht1();
void opdracht2();
void opdracht3();
unsigned char docent_check(unsigned char input);
void print_as_HEX(const unsigned char input);
void opdracht4();
void opdracht5();


#endif