#ifndef SIAMEES___H
#define SIAMEES___H

#include "Kat.h"

class Siamees : public Kat
{
    using Kat::Kat;
};



#endif