#include <iostream>
#include "tentamen.h"

int main()
{
    // Let op: je mag de functies hieronder in en uit commentaar
    //         zetten zodat je ze los van elkaar kunt maken
    // Pro-tip: maak makkelijke vragen eerst
    // opdracht1();
    // opdracht2(); //af
    opdracht3();
    // opdracht4();
    // opdracht5();
    // system("PAUSE");
    return 0;
}